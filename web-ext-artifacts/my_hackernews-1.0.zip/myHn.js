const head = document.head || document.getElementsByTagName("head")[0],
  style = document.createElement("style");

style.type = "text/css";
style.innerHTML = `
    body,
    #hnmain {
        background: #1f1f1f;
    }

    center > a,
    a.storylink,
    a.morelink {
        color: #fff;
    }
`;

head.appendChild(style);
